package com.example.restaurant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
